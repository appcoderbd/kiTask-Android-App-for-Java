package com.dscappstudio.kitask.profile;

import junit.framework.TestCase;

public class EntityTest extends TestCase {

}